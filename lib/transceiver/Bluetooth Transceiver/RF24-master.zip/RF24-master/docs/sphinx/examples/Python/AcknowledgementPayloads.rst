acknowledgement_payloads.py
===========================

.. literalinclude:: ../../../../examples_linux/acknowledgement_payloads.py
    :language: python
    :caption: examples_linux/acknowledgement_payloads.py
    :linenos:
    :lineno-match:
